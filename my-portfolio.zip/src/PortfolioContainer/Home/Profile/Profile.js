import React from "react";
import Typical from 'react-typical';
import "./Profile.css";

export default function Profile() {
    return (
        <div className="profile-container">
            <div className="profile-parent">
                <div className="profile-details">
                    <div className="colz">
                        <div className="colz-icon">
                                   <a href="#">
                            <i className="fa fa-facebook-square"></i>
                        </a>
                        <a href="#">
                            <i className="fa fa-linkedin-square"></i>
                        </a>
                        <a href="#">
                            <i className="fa fa-twitter-square"></i>
                        </a>
                        </div>
                    </div>
                
                <div className="profile-details-name">
                    <span className="Primary-text">
                        {" "}
                        Hello, I'm <span className="highlighted-text">Marklen</span>
                    </span>
                </div>
                <div className="profile-details-role">
                    <span className="primary-text">
                        {" "}
                        <h1>
                            {" "}
                            <Typical 
                                loop={Infinity}
                                steps={[
                                    "CMS",
                                    1000,
                                    "Front-End Developer",
                                    1000,
                                    "React Developer",
                                    1000,
                                    "WIX",
                                    1000,
                                    "HTML, CSS",
                                    1000,
                                    
                                ]}
                            />
                        </h1>
                        <span className="Profile-role-tagline">
                            gruhgrfuhghgiefg ueigh rtgh i h
                        </span>
                    </span>
                </div>
                    <div className="profile-options">
                        <button className="btn primary-btn">
                            {""}
                            Hire Me{" "}
                        </button>
                        <a href='CV.jpg' download='reghtej CV.jpg'>
                            <button className="btn highlighted-btn">Get Resume</button>
                        </a>
                    </div>
                </div>
                <div className="profile-picture">
                    <div className="profile-picture-background">
                        
                    </div>
                </div>
            </div>
        </div>
    )
}